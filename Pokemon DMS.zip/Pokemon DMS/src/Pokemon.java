/**
 * Name: Kiara Caballero
 * Course: CEN 3024C Software Development 1
 * Date: 10/04/2025
 *
 * Class Name: Pokemon
 *
 * Description:
 * The Pokemon class will show one Pokemon in the Daycare Management System.
 * It stores all details such as name, type, level, gender, trainer name, and days stayed.
 * It will also give a method to calculate the daycare fee based on days stayed.
 */

public class Pokemon {
    private int pokemonId;
    private String name;
    private String type;
    private int level;
    private String gender;
    private String trainerName;
    private int daysStayed;

    /**
     * Method Name: Pokemon (Constructor)
     * Purpose: Creates a new Pokemon object with all required attributes.
     * Arguments:
     *  - int pokemonId: The Pokemon’s unique ID number
     *  - String name: Pokemon’s name
     *  - String type: Pokemon’s type
     *  - int level: Pokemon’s level
     *  - String gender: Pokemon’s gender
     *  - String trainerName: Name of the trainer who owns the Pokemon
     *  - int daysStayed: Number of days the Pokemon has stayed in the daycare
     * Return Value: None
     */

    public Pokemon(int pokemonId, String name, String type, int level, String gender, String trainerName, int daysStayed) {
        this.pokemonId = pokemonId;
        this.name = name;
        this.type = type;
        this.level = level;
        this.gender = gender;
        this.trainerName = trainerName;
        this.daysStayed = daysStayed;
    }

    /**
     * Method Name: getPokemonId
     * Purpose: Returns the Pokémon's ID.
     * Arguments: None
     * Return Value: int
     */

    public int getPokemonId() { return pokemonId; }

    /**
     * Method Name: getName
     * Purpose: Returns the Pokémon’s name.
     * Arguments: None
     * Return Value: String
     */

    public String getName() {
        return name;
    }

    /**
     * Method Name: getType
     * Purpose: Returns the Pokémon’s type.
     * Arguments: None
     * Return Value: String
     */

    public String getType() {
        return type;
    }

    /**
     * Method Name: getLevel
     * Purpose: Returns the Pokémon's level.
     * Arguments: None
     * Return Value: int
     */

    public int getLevel() {
        return level;
    }

    /**
     * Method Name: getGender
     * Purpose: Returns the Pokémon’s gender.
     * Arguments: None
     * Return Value: String
     */

    public String getGender() {
        return gender;
    }

    /**
     * Method Name: getTrainerName
     * Purpose: Returns the trainer’s name.
     * Arguments: None
     * Return Value: String
     */

    public String getTrainerName() {
        return trainerName;
    }

    /**
     * Method Name: getDaysStayed
     * Purpose: Returns the number of days this Pokémon stayed in the daycare.
     * Arguments: None
     * Return Value: int
     */

    public int getDaysStayed() {
        return daysStayed;
    }

    /**
     * Method Name: setPokemonId
     * Purpose: Updates the Pokémon’s ID.
     * Arguments: int pokemonId
     * Return Value: None
     */
    public void setPokemonId(int pokemonId) { this.pokemonId = pokemonId; }

    /**
     * Method Name: setName
     * Purpose: Updates the Pokémon’s name.
     * Arguments: String name
     * Return Value: None
     */

    public void setName(String name) { this.name = name; }

    /**
     * Method Name: setType
     * Purpose: Updates the Pokémon’s type.
     * Arguments: String type
     * Return Value: None
     */

    public void setType(String type) { this.type = type; }

    /**
     * Method Name: setLevel
     * Purpose: Updates the Pokémon’s level.
     * Arguments: int level
     * Return Value: None
     */

    public void setLevel(int level) { this.level = level; }

    /**
     * Method Name: setGender
     * Purpose: Updates the Pokémon’s gender.
     * Arguments: String gender
     * Return Value: None
     */

    public void setGender(String gender) { this.gender = gender; }

    /**
     * Method Name: setTrainerName
     * Purpose: Updates the trainer’s name.
     * Arguments: String trainerName
     * Return Value: None
     */

    public void setTrainerName(String trainerName) { this.trainerName = trainerName; }

    /**
     * Method Name: setDaysStayed
     * Purpose: Updates how many days the Pokémon stayed.
     * Arguments: int daysStayed
     * Return Value: None
     */

    public void setDaysStayed(int daysStayed) { this.daysStayed = daysStayed; }


    /**
     * Method: calculateFee
     * Why its needed: Calculates the daycare fee based on the number of days stayed.
     * There are no arguments
     * Return: the total fee calculated
     * Fee Structure:
     * $5 for the first day
     * $3 for each day after that first day
     */
    public double calculateFee() {
        if (daysStayed <= 0) {
            return 0.0;
        } else if (daysStayed == 1) {
            return 5.0;
        } else {
            return 5.0 + (daysStayed - 1) * 3.0;
        }
    }

    /**
     * Method Name: toString
     * Purpose: Returns all Pokémon information as text.
     * Arguments: None
     * Return Value: String
     */

    @Override
    public String toString() {
        return "Pokemon ID: " + pokemonId +
                ", Name: " + name +
                ", Type: " + type +
                ", Level: " + level +
                ", Gender: " + gender +
                ", Trainer: " + trainerName +
                ", Days Stayed: " + daysStayed +
                ", Fee: $" + calculateFee();
    }

}
