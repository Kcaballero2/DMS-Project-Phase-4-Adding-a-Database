/**
 * Name: Kiara Caballero
 * Course: CEN 3024C Software Development 1
 * Date: 11/01/2025
 *
 * Class Name: DatabaseConnector
 * Description:
 * This class is attempting to connect the Pokémon Daycare Management System
 * to MySQL database.
 */


import java.sql.*;
import java.util.Scanner;

public class DatabaseConnector {
    private Connection connection;

    /**
     * Method Name: connect
     * Purpose: Establishing a connection.
     * Arguments: None
     * Return Value: None
     */

    public void connect() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter MySQL server address (e.g., localhost:3306): ");
        String host = scanner.nextLine().trim();

        System.out.print("Enter database name: ");
        String dbName = scanner.nextLine().trim();

        System.out.print("Enter MySQL username: ");
        String username = scanner.nextLine().trim();

        System.out.print("Enter MySQL password: ");
        String password = scanner.nextLine().trim();


        String url = "jdbc:mysql://localhost:3306/pokemon_daycare?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
        System.out.println("Connecting to: " + url);


        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            connection = DriverManager.getConnection(url, username, password);
            System.out.println("Connected to database: " + dbName);
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found.");
        } catch (SQLException e) {
            System.out.println("Connection failed: " + e.getMessage());
        }
    }

    public Connection getConnection() {
        return connection;
    }
}


