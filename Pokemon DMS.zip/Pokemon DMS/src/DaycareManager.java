/**
 * Name: Kiara Caballero
 * Course: CEN 3024C Software Development 1
 * Date: 11/02/2025
 *
 * Class Name: DaycareManager
 * Description:
 * The DaycareManager class connects to the Pokémon Daycare database
 */

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DaycareManager {
    private final Connection connection;

    /**
     * Method Name: DaycareManager
     * Purpose: It will run a MySQL database connection.
     * Arguments:
     * Return Value: None
     */
    public DaycareManager(Connection connection) {
        this.connection = connection;
    }

    /**
     * Method Name: addPokemon
     * Purpose: Inserts a new Pokémon record into the database.
     * Arguments: Pokemon p
     * Return Value: boolean
     */
    public boolean addPokemon(Pokemon p) {
        String sql = "INSERT INTO pokemon (pokemon_id, name, type, level, gender, trainer_name, days_stayed) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, p.getPokemonId());
            stmt.setString(2, p.getName());
            stmt.setString(3, p.getType());
            stmt.setInt(4, p.getLevel());
            stmt.setString(5, p.getGender());
            stmt.setString(6, p.getTrainerName());
            stmt.setInt(7, p.getDaysStayed());
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error adding Pokémon: " + e.getMessage());
            return false;
        }
    }

    /**
     * Method Name: getAllPokemon
     * Purpose: Retrieves all Pokémon from the database
     * Arguments: None
     * Return Value: List<Pokemon>
     */
    public List<Pokemon> getAllPokemon() {
        List<Pokemon> list = new ArrayList<>();
        String sql = "SELECT * FROM pokemon";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Pokemon p = new Pokemon(
                        rs.getInt("pokemon_id"),
                        rs.getString("name"),
                        rs.getString("type"),
                        rs.getInt("level"),
                        rs.getString("gender"),
                        rs.getString("trainer_name"),
                        rs.getInt("days_stayed")
                );
                list.add(p);
            }
        } catch (SQLException e) {
            System.out.println("Error reading Pokémon: " + e.getMessage());
        }
        return list;
    }

    /**
     * Method Name: removePokemon
     * Purpose: Deletes a Pokémon from the database via ID.
     * Arguments: int id
     * Return Value: boolean
     */
    public boolean removePokemon(int id) {
        String sql = "DELETE FROM pokemon WHERE pokemon_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error removing Pokémon: " + e.getMessage());
            return false;
        }
    }

    /**
     * Method Name: updatePokemon
     * Purpose: Updates an existing Pokémon
     * Arguments: Pokemon p
     * Return Value: boolean
     */
    public boolean updatePokemon(Pokemon p) {
        String sql = "UPDATE pokemon SET name=?, type=?, level=?, gender=?, trainer_name=?, days_stayed=? WHERE pokemon_id=?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, p.getName());
            stmt.setString(2, p.getType());
            stmt.setInt(3, p.getLevel());
            stmt.setString(4, p.getGender());
            stmt.setString(5, p.getTrainerName());
            stmt.setInt(6, p.getDaysStayed());
            stmt.setInt(7, p.getPokemonId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error updating Pokémon: " + e.getMessage());
            return false;
        }
    }

    /**
     * Method Name: findPokemonById
     * Purpose: Finds and returns a Pokémon via ID.
     * Arguments: int id
     * Return Value: Pokemon
     */
    public Pokemon findPokemonById(int id) {
        String sql = "SELECT * FROM pokemon WHERE pokemon_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Pokemon(
                        rs.getInt("pokemon_id"),
                        rs.getString("name"),
                        rs.getString("type"),
                        rs.getInt("level"),
                        rs.getString("gender"),
                        rs.getString("trainer_name"),
                        rs.getInt("days_stayed")
                );
            }
        } catch (SQLException e) {
            System.out.println("Error finding Pokémon: " + e.getMessage());
        }
        return null;
    }
}


