/**
 * Name: Kiara Caballero
 * Course: CEN 3024C Software Development 1
 * Date: 11/07/2025
 *
 * Class Name: Testing
 *
 * Description:
 * This class is used to test the database connection
 */

public class Testing {

    /**
     * Method Name: main
     * Purpose: Runs a test that connects to the database.
     * Arguments: String[] args
     * Return Value: None
     */

    public static void main(String[] args) {
        DatabaseConnector db = new DatabaseConnector();
        db.connect();
    }
}
