public class Testing {
    public static void main(String[] args) {
        DatabaseConnector db = new DatabaseConnector();
        db.connect();
    }
}
