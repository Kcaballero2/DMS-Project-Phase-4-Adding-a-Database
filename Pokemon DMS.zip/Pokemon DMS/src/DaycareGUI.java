/**
 * Name: Kiara Caballero
 * Course: CEN 3024C Software Development 1
 * Date: 11/03/2025
 *
 * Class Name: DaycareGUI
 * Description:
 * This GUI connects to a MySQL database for the Pokémon Daycare Management System.
 */

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.util.List;

public class DaycareGUI {

    private DaycareManager manager;
    private DefaultTableModel tableModel;

    /**
     * Method Name: main
     * Purpose: Starts the GUI.
     * Arguments: String[] args
     * Return Value: None
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new DaycareGUI().connectAndLaunch());
    }

    /**
     * Method Name: connectAndLaunch
     * Purpose: Connects to the database.
     * Arguments: None
     * Return Value: None
     */
    public void connectAndLaunch() {
        try {
            DatabaseConnector dbConnector = new DatabaseConnector();
            dbConnector.connect(); // Prompts user for info
            Connection connection = dbConnector.getConnection();

            if (connection == null) {
                JOptionPane.showMessageDialog(null,
                        "Database connection failed. Exiting program.",
                        "Connection Error", JOptionPane.ERROR_MESSAGE);
                System.exit(0);
            }

            this.manager = new DaycareManager(connection);
            createAndShowGUI();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,
                    "Error during startup: " + e.getMessage(),
                    "Startup Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Method Name: createAndShowGUI
     * Purpose: Builds and displays the main Pokémon Daycare GUI.
     * Arguments: None
     * Return Value: None
     */
    private void createAndShowGUI() {
        JFrame frame = new JFrame("Pokémon Daycare Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(850, 550);
        frame.setLocationRelativeTo(null);


        tableModel = new DefaultTableModel(
                new Object[]{"ID", "Name", "Type", "Level", "Gender", "Trainer", "Days Stayed"}, 0
        );
        JTable table = new JTable(tableModel);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setRowHeight(25);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        frame.add(new JScrollPane(table), BorderLayout.CENTER);


        JMenuBar menuBar = new JMenuBar();

        JMenu manageMenu = new JMenu("Manage Pokémon");
        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem addItem = new JMenuItem("Add Pokémon");
        JMenuItem updateItem = new JMenuItem("Update Pokémon");
        JMenuItem removeItem = new JMenuItem("Remove Pokémon");
        JMenuItem viewItem = new JMenuItem("Refresh Pokémon List");
        JMenuItem feeItem = new JMenuItem("Calculate Fee");
        JMenuItem exitItem = new JMenuItem("Exit");

        manageMenu.add(addItem);
        manageMenu.add(updateItem);
        manageMenu.add(removeItem);
        manageMenu.addSeparator();
        manageMenu.add(viewItem);

        toolsMenu.add(feeItem);
        toolsMenu.add(exitItem);

        menuBar.add(manageMenu);
        menuBar.add(toolsMenu);
        frame.setJMenuBar(menuBar);


        addItem.addActionListener(e -> addPokemon());
        updateItem.addActionListener(e -> updatePokemon(table));
        removeItem.addActionListener(e -> removePokemon(table));
        viewItem.addActionListener(e -> refreshTable());
        feeItem.addActionListener(e -> calculateFee(table));
        exitItem.addActionListener(e -> System.exit(0));


        refreshTable();

        frame.setVisible(true);
    }

    /**
     * Method Name: refreshTable
     * Purpose: Loads and displays all Pokémon from the database.
     * Arguments: None
     * Return Value: None
     */
    private void refreshTable() {
        tableModel.setRowCount(0);
        List<Pokemon> pokemonList = manager.getAllPokemon();
        for (Pokemon p : pokemonList) {
            tableModel.addRow(new Object[]{
                    p.getPokemonId(),
                    p.getName(),
                    p.getType(),
                    p.getLevel(),
                    p.getGender(),
                    p.getTrainerName(),
                    p.getDaysStayed()
            });
        }
    }

    /**
     * Method Name: addPokemon
     * Purpose: Adds a new Pokémon to the database.
     * Arguments: None
     * Return Value: None
     */
    private void addPokemon() {
        try {
            int id = Integer.parseInt(JOptionPane.showInputDialog("Enter Pokémon ID:"));
            String name = JOptionPane.showInputDialog("Enter Pokémon Name:");
            String type = JOptionPane.showInputDialog("Enter Pokémon Type:");
            int level = Integer.parseInt(JOptionPane.showInputDialog("Enter Level (1–100):"));
            String gender = JOptionPane.showInputDialog("Enter Gender (M/F/Unknown):");
            String trainer = JOptionPane.showInputDialog("Enter Trainer Name:");
            int days = Integer.parseInt(JOptionPane.showInputDialog("Enter Days Stayed:"));

            Pokemon p = new Pokemon(id, name, type, level, gender, trainer, days);
            if (manager.addPokemon(p)) {
                JOptionPane.showMessageDialog(null, "Pokémon added successfully!");
                refreshTable();
            } else {
                JOptionPane.showMessageDialog(null, "Error adding Pokémon.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Invalid number input.");
        }
    }

    /**
     * Method Name: removePokemon
     * Purpose: Deletes the selected Pokémon from the database.
     * Arguments: JTable table
     * Return Value: None
     */
    private void removePokemon(JTable table) {
        int selected = table.getSelectedRow();
        if (selected == -1) {
            JOptionPane.showMessageDialog(null, "Select a Pokémon to remove.");
            return;
        }
        int id = (int) table.getValueAt(selected, 0);
        if (manager.removePokemon(id)) {
            JOptionPane.showMessageDialog(null, "Pokémon removed successfully.");
            refreshTable();
        } else {
            JOptionPane.showMessageDialog(null, "Error removing Pokémon.");
        }
    }

    /**
     * Method Name: updatePokemon
     * Purpose: Updates the selected Pokémon’s details in the database.
     * Arguments: JTable table
     * Return Value: None
     */
    private void updatePokemon(JTable table) {
        int selected = table.getSelectedRow();
        if (selected == -1) {
            JOptionPane.showMessageDialog(null, "Select a Pokémon to update.");
            return;
        }

        try {
            int id = (int) table.getValueAt(selected, 0);
            String name = JOptionPane.showInputDialog("Enter new name:", table.getValueAt(selected, 1));
            String type = JOptionPane.showInputDialog("Enter new type:", table.getValueAt(selected, 2));
            int level = Integer.parseInt(JOptionPane.showInputDialog("Enter new level (1–100):", table.getValueAt(selected, 3)));
            String gender = JOptionPane.showInputDialog("Enter new gender (M/F/Unknown):", table.getValueAt(selected, 4));
            String trainer = JOptionPane.showInputDialog("Enter new trainer name:", table.getValueAt(selected, 5));
            int days = Integer.parseInt(JOptionPane.showInputDialog("Enter new days stayed:", table.getValueAt(selected, 6)));

            Pokemon updated = new Pokemon(id, name, type, level, gender, trainer, days);
            if (manager.updatePokemon(updated)) {
                JOptionPane.showMessageDialog(null, "Pokémon updated successfully!");
                refreshTable();
            } else {
                JOptionPane.showMessageDialog(null, "Error updating Pokémon.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Invalid number input.");
        }
    }

    /**
     * Method Name: calculateFee
     * Purpose: Calculates the total fee
     * Arguments: JTable table
     * Return Value: None
     */
    private void calculateFee(JTable table) {
        int selected = table.getSelectedRow();
        if (selected == -1) {
            JOptionPane.showMessageDialog(null, "Select a Pokémon first.");
            return;
        }

        int days = (int) table.getValueAt(selected, 6);
        double fee = (days <= 0) ? 0.0 : (days == 1 ? 5.0 : 5.0 + (days - 1) * 3.0);
        JOptionPane.showMessageDialog(null, "Total Fee: $" + fee);
    }
}

