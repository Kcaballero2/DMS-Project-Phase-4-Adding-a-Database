/**
 * Name: Kiara Caballero
 * Course: CEN 3024C Software Development 1
 * Date: 11/03/2025
 *
 * Class Name: MainApplication
 * Description:
 * This is the main area for the Pokémon Daycare Management System.
 * It connects to the MySQL database through DatabaseConnector and allows
 * users (the staff) to perform  operations (Create, Read, Update, Delete)
 */

import java.sql.Connection;
import java.util.List;
import java.util.Scanner;

public class MainApplication {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        System.out.println("Pokémon Daycare Database");
        DatabaseConnector connector = new DatabaseConnector();
        connector.connect();

        Connection connection = connector.getConnection();
        if (connection == null) {
            System.out.println("Could not connect to the database. Exiting program.");
            return;
        }

        DaycareManager manager = new DaycareManager(connection);


        boolean running = true;
        while (running) {
            System.out.println("\nPokémon Daycare Management System");
            System.out.println("1. View All Pokémon");
            System.out.println("2. Add Pokémon");
            System.out.println("3. Update Pokémon");
            System.out.println("4. Remove Pokémon");
            System.out.println("5. Calculate Fee");
            System.out.println("6. Exit");
            System.out.print("Select an option: ");

            String input = scanner.nextLine().trim();
            int choice;
            try {
                choice = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number between 1 and 6.");
                continue;
            }

            /**
             * Case 1: View All Pokémon
             * Purpose: Displays all Pokémon currently stored in the database.
             * Arguments: None
             * Return Value: void
             */

            switch (choice) {
                case 1 -> {
                    List<Pokemon> pokemonList = manager.getAllPokemon();
                    if (pokemonList.isEmpty()) {
                        System.out.println("No Pokémon found in the daycare.");
                    } else {
                        System.out.println("\nPokémon in Daycare");
                        for (Pokemon p : pokemonList) {
                            System.out.println(p);
                        }
                    }
                }

                /**
                 * Case 2: Add Pokémon
                 * Purpose: Allows users to manually add a Pokémon
                 * Arguments: None
                 * Return Value: void
                 */

                case 2 -> {
                    try {
                        System.out.print("Enter Pokémon ID: ");
                        int id = Integer.parseInt(scanner.nextLine().trim());
                        System.out.print("Enter Name: ");
                        String name = scanner.nextLine().trim();
                        System.out.print("Enter Type: ");
                        String type = scanner.nextLine().trim();
                        System.out.print("Enter Level (1–100): ");
                        int level = Integer.parseInt(scanner.nextLine().trim());
                        System.out.print("Enter Gender (M/F/Unknown): ");
                        String gender = scanner.nextLine().trim();
                        System.out.print("Enter Trainer Name: ");
                        String trainer = scanner.nextLine().trim();
                        System.out.print("Enter Days Stayed: ");
                        int days = Integer.parseInt(scanner.nextLine().trim());

                        Pokemon p = new Pokemon(id, name, type, level, gender, trainer, days);
                        if (manager.addPokemon(p)) {
                            System.out.println("Pokémon added successfully!");
                        } else {
                            System.out.println("Failed to add Pokémon.");
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid number input.");
                    }
                }

                /**
                 * Case 3: Update Pokémon
                 * Purpose: Updates an existing Pokémon’s details
                 * Arguments: None
                 * Return Value: void
                 */

                case 3 -> {
                    System.out.print("Enter Pokémon ID to update: ");
                    int id = Integer.parseInt(scanner.nextLine().trim());
                    Pokemon existing = manager.findPokemonById(id);
                    if (existing == null) {
                        System.out.println("Pokémon not found.");
                        break;
                    }

                    System.out.print("Enter new Name (leave blank to keep current): ");
                    String name = scanner.nextLine().trim();
                    if (name.isEmpty()) name = existing.getName();

                    System.out.print("Enter new Type (leave blank to keep current): ");
                    String type = scanner.nextLine().trim();
                    if (type.isEmpty()) type = existing.getType();

                    System.out.print("Enter new Level (1–100, blank to keep current): ");
                    String levelInput = scanner.nextLine().trim();
                    int level = existing.getLevel();
                    if (!levelInput.isEmpty()) {
                        try {
                            level = Integer.parseInt(levelInput);
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid level input. Keeping old value.");
                        }
                    }

                    System.out.print("Enter new Gender (M/F/Unknown, blank to keep current): ");
                    String gender = scanner.nextLine().trim();
                    if (gender.isEmpty()) gender = existing.getGender();

                    System.out.print("Enter new Trainer Name (blank to keep current): ");
                    String trainer = scanner.nextLine().trim();
                    if (trainer.isEmpty()) trainer = existing.getTrainerName();

                    System.out.print("Enter new Days Stayed (blank to keep current): ");
                    String daysInput = scanner.nextLine().trim();
                    int days = existing.getDaysStayed();
                    if (!daysInput.isEmpty()) {
                        try {
                            days = Integer.parseInt(daysInput);
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid days input. Keeping old value.");
                        }
                    }

                    Pokemon updated = new Pokemon(id, name, type, level, gender, trainer, days);
                    if (manager.updatePokemon(updated)) {
                        System.out.println("Pokémon updated successfully!");
                    } else {
                        System.out.println("Update failed.");
                    }
                }

                /**
                 * Case 4: Remove Pokémon
                 * Purpose: Deletes a Pokémon record via ID
                 * Arguments: None
                 * Return Value: void
                 */

                case 4 -> {
                    System.out.print("Enter Pokémon ID to remove: ");
                    try {
                        int id = Integer.parseInt(scanner.nextLine().trim());
                        if (manager.removePokemon(id)) {
                            System.out.println("Pokémon removed successfully!");
                        } else {
                            System.out.println("Pokémon not found.");
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid ID. Please enter a number.");
                    }
                }

                /**
                 * Case 5: Calculate Fee
                 * Purpose: Calculates the daycare fee for a Pokémon
                 * Arguments: None
                 * Return Value: void
                 */

                /**
                 * Case 5: Calculate Fee
                 * Purpose: Calculates the daycare fee for a Pokémon
                 * Arguments: None
                 * Return Value: void
                 */
                case 5 -> {
                    System.out.print("Enter Pokémon ID to calculate fee: ");
                    try {
                        int id = Integer.parseInt(scanner.nextLine().trim());
                        Pokemon p = manager.findPokemonById(id); // Always fetch from DB
                        if (p != null) {
                            System.out.println("Total Fee: $" + p.calculateFee());
                        } else {
                            System.out.println("Pokémon not found ");
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid ID. Please enter a number.");
                    }
                }


                case 6 -> {
                    running = false;
                    System.out.println("Shutting down... Have a nice day :D!");
                }

                default -> System.out.println("Invalid choice. Please try again.");
            }
        }

        scanner.close();
    }
}

